// import React from "react";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faCheck } from "@fortawesome/free-solid-svg-icons";
// import Featured from "../../components/featured/Featured";
// import TrustedBy from "../../components/trustedBy/TrustedBy";
// import Slide from "../../components/slider/Slider";
// import CatCard from "../../components/catCard/CatCard";
// import ProjectCard from "../../components/projectCards/ProjectCard";
// import { cards, projects } from "../../data";

// const Home = () => {
//   return (
//     <div className="home">
//       <Featured />
//       <TrustedBy />

//       {/* Category Slide Section */}
//       <Slide slidesToShow={5} arrowsScroll={5}>
//         {cards.map((card) => (
//           <CatCard key={card.id} card={card} />
//         ))}
//       </Slide>

//       {/* Features Section */}
//       <div className="bg-green-50 flex justify-center py-20">
//         <div className="max-w-6xl flex items-center gap-20 px-5 md:px-10">
//           <div className="flex-1 space-y-5">
//             <h1 className="text-3xl font-semibold">
//               A whole world of freelance talent at your fingertips
//             </h1>
//             {[
//               "The best for every budget",
//               "Quality work done quickly",
//               "Protected payments, every time",
//               "24/7 support",
//             ].map((text, index) => (
//               <div key={index}>
//                 <div className="flex items-center gap-3 text-lg font-medium text-gray-700">
//                   <FontAwesomeIcon icon={faCheck} className="text-green-500 text-xl" />
//                   {text}
//                 </div>
//                 <p className="text-gray-600">
//                   {index === 0
//                     ? "Find high-quality services at every price point. No hourly rates, just project-based pricing."
//                     : index === 1
//                     ? "Find the right freelancer to begin working on your project within minutes."
//                     : index === 2
//                     ? "Always know what you'll pay upfront. Your payment isn't released until you approve the work."
//                     : "Find high-quality services at every price point. No hourly rates, just project-based pricing."}
//                 </p>
//               </div>
//             ))}
//           </div>
//           <div className="flex-1">
//             <video className="w-full rounded-md shadow-md" src="./img/video.mp4" controls />
//           </div>
//         </div>
//       </div>

//       {/* Explore Marketplace */}
//       <div className="flex justify-center py-20">
//         <div className="max-w-6xl w-full px-5">
//           <h1 className="text-3xl font-semibold text-gray-700 mb-10">Explore the marketplace</h1>
//           <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
//             {[
//               { title: "Graphics & Design", icon: "graphics-design.d32a2f8.svg" },
//               { title: "Digital Marketing", icon: "online-marketing.74e221b.svg" },
//               { title: "Writing & Translation", icon: "writing-translation.32ebe2e.svg" },
//               { title: "Video & Animation", icon: "video-animation.f0d9d71.svg" },
//               { title: "Music & Audio", icon: "music-audio.320af20.svg" },
//               { title: "Programming & Tech", icon: "programming.9362366.svg" },
//               { title: "Business", icon: "business.bbdf319.svg" },
//               { title: "Lifestyle", icon: "lifestyle.745b575.svg" },
//               { title: "Data", icon: "data.718910f.svg" },
//               { title: "Photography", icon: "photography.01cf943.svg" },
//             ].map(({ title, icon }, index) => (
//               <div
//                 key={index}
//                 className="flex flex-col items-center justify-center text-center cursor-pointer hover:scale-105 transition transform duration-300"
//               >
//                 <img
//                   src={`https://fiverr-res.cloudinary.com/npm-assets/@fiverr/logged_out_homepage_perseus/apps/${icon}`}
//                   alt={title}
//                   className="w-12 h-12"
//                 />
//                 <div className="w-12 h-0.5 bg-gray-300 my-2 transition-all duration-300 group-hover:w-20 group-hover:bg-green-500"></div>
//                 <span className="text-gray-600">{title}</span>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* Business Section */}
//       <div className="bg-blue-900 text-white flex justify-center py-20">
//         <div className="max-w-6xl flex items-center gap-20 px-5 md:px-10">
//           <div className="flex-1 space-y-5">
//             <h1 className="text-3xl font-semibold">
//               liverr <i className="font-light">business</i>
//             </h1>
//             <h1 className="text-3xl font-semibold">
//               A business solution designed for <i className="font-light">teams</i>
//             </h1>
//             <p className="text-lg">
//               Upgrade to a curated experience packed with tools and benefits, dedicated to businesses
//             </p>
//             {[
//               "Connect to freelancers with proven business experience",
//               "Get matched with the perfect talent by a customer success manager",
//               "Manage teamwork and boost productivity with one powerful workspace",
//             ].map((text, index) => (
//               <div key={index} className="flex items-center gap-3 text-lg font-light">
//                 <FontAwesomeIcon icon={faCheck} className="text-green-500 text-xl" />
//                 {text}
//               </div>
//             ))}
//             <button className="bg-green-500 hover:bg-green-600 text-white py-2 px-5 rounded-md mt-5">
//               Explore Liverr Business
//             </button>
//           </div>
//           <div className="flex-1">
//             <img
//               className="w-full rounded-md shadow-md"
//               src="https://fiverr-res.cloudinary.com/q_auto,f_auto,w_870,dpr_2.0/v1/attachments/generic_asset/asset/d9c17ceebda44764b591a8074a898e63-1599597624768/business-desktop-870-x2.png"
//               alt=""
//             />
//           </div>
//         </div>
//       </div>

//       {/* Projects Slide Section */}
//       <Slide slidesToShow={4} arrowsScroll={4} >
//         {projects.map((card) => (
//           <ProjectCard key={card.id} card={card} />
//         ))}
//       </Slide>
//     </div>
//   );
// };

// export default Home;
import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck } from "@fortawesome/free-solid-svg-icons";
import Featured from "../../components/featured/Featured";
import TrustedBy from "../../components/trustedBy/TrustedBy";
import Slide from "../../components/slider/Slider";
import CatCard from "../../components/catCard/CatCard";
import ProjectCard from "../../components/projectCards/ProjectCard";
import { cards, projects } from "../../data";

const Home = () => {
  return (
    <div className="home">
      <Featured />
      <TrustedBy />

      {/* Category Slide Section */}
      <div className="py-16 bg-gradient-to-r from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Popular Categories</h2>
          <Slide slidesToShow={5} arrowsScroll={5}>
            {cards.map((card) => (
              <CatCard key={card.id} card={card} />
            ))}
          </Slide>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gradient-to-b from-green-50 to-green-100 py-24">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-12 md:gap-20 px-5 md:px-10">
          <div className="flex-1 space-y-8">
            <h2 className="text-4xl font-bold text-gray-800 leading-tight">
              A whole world of freelance talent at your fingertips
            </h2>
            {[
              "The best for every budget",
              "Quality work done quickly",
              "Protected payments, every time",
              "24/7 support",
            ].map((text, index) => (
              <div key={index} className="transform transition hover:translate-x-2 duration-300">
                <div className="flex items-center gap-3 text-xl font-semibold text-gray-800 mb-2">
                  <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center shadow-md">
                    <FontAwesomeIcon icon={faCheck} className="text-white text-sm" />
                  </div>
                  {text}
                </div>
                <p className="text-gray-600 ml-11 text-lg">
                  {index === 0
                    ? "Find high-quality services at every price point. No hourly rates, just project-based pricing."
                    : index === 1
                    ? "Find the right freelancer to begin working on your project within minutes."
                    : index === 2
                    ? "Always know what you'll pay upfront. Your payment isn't released until you approve the work."
                    : "Questions or concerns? Our dedicated support team is ready to help, anytime."}
                </p>
              </div>
            ))}
          </div>
          <div className="flex-1">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-blue-500 rounded-lg blur opacity-25"></div>
              <video 
                className="relative w-full rounded-lg shadow-xl border-4 border-white" 
                src="./img/video.mp4" 
                controls 
              />
            </div>
          </div>
        </div>
      </div>

      {/* Explore Marketplace */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-6xl mx-auto px-5">
          <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">
            Explore the <span className="text-green-500">marketplace</span>
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-8">
            {[
              { title: "Graphics & Design", icon: "graphics-design.d32a2f8.svg" },
              { title: "Digital Marketing", icon: "online-marketing.74e221b.svg" },
              { title: "Writing & Translation", icon: "writing-translation.32ebe2e.svg" },
              { title: "Video & Animation", icon: "video-animation.f0d9d71.svg" },
              { title: "Music & Audio", icon: "music-audio.320af20.svg" },
              { title: "Programming & Tech", icon: "programming.9362366.svg" },
              { title: "Business", icon: "business.bbdf319.svg" },
              { title: "Lifestyle", icon: "lifestyle.745b575.svg" },
              { title: "Data", icon: "data.718910f.svg" },
              { title: "Photography", icon: "photography.01cf943.svg" },
            ].map(({ title, icon }, index) => (
              <div
                key={index}
                className="group flex flex-col items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-4">
                  <img
                    src={`https://fiverr-res.cloudinary.com/npm-assets/@fiverr/logged_out_homepage_perseus/apps/${icon}`}
                    alt={title}
                    className="w-10 h-10"
                  />
                </div>
                <div className="w-12 h-0.5 bg-gray-200 my-3 transition-all duration-300 group-hover:w-16 group-hover:bg-green-500"></div>
                <span className="text-gray-700 font-medium text-center">{title}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Business Section */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white py-24">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-12 md:gap-20 px-5 md:px-10">
          <div className="flex-1 space-y-6">
            <div className="inline-block bg-gradient-to-r from-blue-400 to-green-400 px-6 py-2 rounded-full shadow-lg mb-4">
              <h3 className="text-2xl font-bold">
                liverr <span className="font-light">business</span>
              </h3>
            </div>
            <h2 className="text-4xl font-bold leading-tight">
              A business solution designed for <span className="italic font-light">teams</span>
            </h2>
            <p className="text-xl text-blue-100">
              Upgrade to a curated experience packed with tools and benefits, dedicated to businesses
            </p>
            {[
              "Connect to freelancers with proven business experience",
              "Get matched with the perfect talent by a customer success manager",
              "Manage teamwork and boost productivity with one powerful workspace",
            ].map((text, index) => (
              <div key={index} className="flex items-center gap-4 text-lg">
                <div className="w-6 h-6 rounded-full bg-green-400 flex items-center justify-center flex-shrink-0">
                  <FontAwesomeIcon icon={faCheck} className="text-blue-900 text-sm" />
                </div>
                <span>{text}</span>
              </div>
            ))}
            <button className="mt-8 bg-green-500 hover:bg-green-600 text-white py-3 px-8 rounded-lg shadow-lg transition duration-300 transform hover:translate-y-1 font-bold text-lg">
              Explore Liverr Business
            </button>
          </div>
          <div className="flex-1">
            <div className="relative">
              <div className="absolute -inset-2 bg-gradient-to-r from-green-400 to-blue-400 rounded-lg blur opacity-30"></div>
              <img
                className="relative w-full rounded-lg shadow-2xl"
                src="https://fiverr-res.cloudinary.com/q_auto,f_auto,w_870,dpr_2.0/v1/attachments/generic_asset/asset/d9c17ceebda44764b591a8074a898e63-1599597624768/business-desktop-870-x2.png"
                alt="Fiverr Business"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Projects Slide Section */}
      <div className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-2 text-center">Inspiring projects</h2>
          <p className="text-xl text-gray-600 text-center mb-10">Handpicked projects for you</p>
        </div>
        <Slide slidesToShow={4} arrowsScroll={4}>
          {projects.map((card) => (
            <ProjectCard key={card.id} card={card} />
          ))}
        </Slide>
      </div>
    </div>
  );
};

export default Home;